package cc.blynk.integration.model.http;

/**
 * The Blynk Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 28.12.15.
 */
public class PinJsonResponse {

    String[] values;

}
