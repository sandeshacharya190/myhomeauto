package cc.blynk.server.core.model.enums;

/**
 * The Blynk Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 20.03.17.
 */
public enum ProvisionType {

    STATIC,
    DYNAMIC

}
