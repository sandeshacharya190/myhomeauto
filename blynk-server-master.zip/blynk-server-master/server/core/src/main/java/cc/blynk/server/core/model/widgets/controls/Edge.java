package cc.blynk.server.core.model.widgets.controls;

public enum Edge {

    ROUNDED, SHARP, PILL, TEXT

}
