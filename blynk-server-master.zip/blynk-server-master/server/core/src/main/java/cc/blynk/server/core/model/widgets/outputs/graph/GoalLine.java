package cc.blynk.server.core.model.widgets.outputs.graph;

/**
 * The Blynk Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 28.03.16.
 */
public enum GoalLine {

    GOAL, ABOVE_GOAL, BELOW_GOAL

}
