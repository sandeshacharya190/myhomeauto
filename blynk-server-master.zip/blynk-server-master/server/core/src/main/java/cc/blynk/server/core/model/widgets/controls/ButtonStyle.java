package cc.blynk.server.core.model.widgets.controls;

public enum ButtonStyle {

    SOLID, OUTLINE

}
