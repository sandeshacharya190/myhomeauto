package cc.blynk.server.core.model.widgets.ui.image;

public enum ImageSource {

    URL, ALBUM, PREDEFINED

}
