package cc.blynk.server.core.model.widgets;

/**
 * The Blynk Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 24.08.17.
 */
public interface CopyObject<T> {

    T copy();

}
