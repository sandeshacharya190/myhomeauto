package cc.blynk.server.core.model.widgets.outputs.graph;

/**
 * The Blynk Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 21.06.17.
 */
public enum GraphType {

    LINE, FILLED_LINE, BAR, BINARY

}
