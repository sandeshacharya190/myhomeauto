package cc.blynk.server.core.model.widgets.ui.reporting.type;

/**
 * The Blynk Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 22.05.18.
 */
public enum ReportDurationType {

    CUSTOM, INFINITE

}
