package cc.blynk.server.api.http.pojo;

/**
 * The Blynk Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 04.08.16.
 */
public class PinData {

    public String value;

    public long timestamp;

}
